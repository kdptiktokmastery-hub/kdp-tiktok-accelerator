import { motion } from "framer-motion";
import { TrendingUp, Flame } from "lucide-react";

const niches = [
  { genre: "Shadow Work Journals", growth: "+342%", potential: 9.4, status: "Hot" },
  { genre: "Dark Academia Romance", growth: "+218%", potential: 8.7, status: "Hot" },
  { genre: "Cozy Fantasy", growth: "+187%", potential: 8.2, status: "Rising" },
  { genre: "Spicy Romantasy", growth: "+156%", potential: 7.9, status: "Hot" },
  { genre: "Anxiety Workbooks", growth: "+134%", potential: 7.5, status: "Rising" },
  { genre: "Cottagecore Coloring Books", growth: "+112%", potential: 7.1, status: "Steady" },
  { genre: "Manifestation Planners", growth: "+98%", potential: 6.8, status: "Rising" },
  { genre: "True Crime Zines", growth: "+87%", potential: 6.4, status: "Steady" },
];

const statusColors: Record<string, string> = {
  Hot: "bg-primary/10 text-primary",
  Rising: "bg-accent/10 text-accent",
  Steady: "bg-muted text-muted-foreground",
};

const TrendDashboard = () => {
  return (
    <section id="trends" className="py-24 md:py-32">
      <div className="container max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: [0.2, 0, 0, 1] }}
        >
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="w-5 h-5 text-primary" strokeWidth={1.5} />
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-widest">Trend Dashboard</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tighter text-foreground mb-2">
            This Week's Top BookTok Niches
          </h2>
          <p className="text-sm text-muted-foreground mb-8">Data updated 14 minutes ago.</p>

          <div className="card-surface overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left text-muted-foreground uppercase text-[11px] tracking-widest font-medium px-6 py-4">Genre</th>
                    <th className="text-right text-muted-foreground uppercase text-[11px] tracking-widest font-medium px-6 py-4">Growth %</th>
                    <th className="text-right text-muted-foreground uppercase text-[11px] tracking-widest font-medium px-6 py-4">Viral Potential</th>
                    <th className="text-right text-muted-foreground uppercase text-[11px] tracking-widest font-medium px-6 py-4">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {niches.map((niche, i) => (
                    <tr key={i} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors duration-200">
                      <td className="px-6 py-4 text-sm font-medium text-foreground flex items-center gap-2">
                        {niche.status === "Hot" && <Flame className="w-3.5 h-3.5 text-accent" strokeWidth={1.5} />}
                        {niche.genre}
                      </td>
                      <td className="px-6 py-4 text-sm text-right font-mono-data text-primary">{niche.growth}</td>
                      <td className="px-6 py-4 text-sm text-right font-mono-data text-foreground">{niche.potential}</td>
                      <td className="px-6 py-4 text-right">
                        <span className={`inline-flex px-2.5 py-1 rounded-md text-[11px] font-medium ${statusColors[niche.status]}`}>
                          {niche.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default TrendDashboard;
