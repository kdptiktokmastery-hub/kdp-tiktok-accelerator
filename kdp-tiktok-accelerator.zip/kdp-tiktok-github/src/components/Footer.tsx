import { Mail, Globe, Twitter } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-card border-t border-border">
      <div className="container max-w-5xl py-16">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">K</span>
              </div>
              <span className="font-display font-bold text-foreground">KDP Accelerator</span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Empowering Amazon KDP authors with cutting-edge tools, data-driven insights, and automation strategies to maximize profitability and market reach.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {[
                { label: "Trend Dashboard", href: "#trends" },
                { label: "Script Generator", href: "#generator" },
                { label: "Resources", href: "#resources" },
              ].map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">Get In Touch</h3>
            <div className="space-y-3">
              <a
                href="mailto:kdptiktokmastery@gmail.com"
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                <Mail className="w-4 h-4" />
                kdptiktokmastery@gmail.com
              </a>
              <a
                href="https://www.kdptiktok.com"
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                <Globe className="w-4 h-4" />
                www.kdptiktok.com
              </a>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-border my-8" />

        {/* Bottom Section */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <p className="text-xs text-muted-foreground">
            © 2025 KDP TikTok Profit Accelerator. All rights reserved.
          </p>

          {/* Social Links */}
          <div className="flex items-center gap-4">
            <a
              href="#"
              className="p-2 rounded-lg bg-muted/50 hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
              aria-label="Visit our website"
            >
              <Globe className="w-4 h-4" />
            </a>
            <a
              href="#"
              className="p-2 rounded-lg bg-muted/50 hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
              aria-label="Follow on social media"
            >
              <Twitter className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Legal Disclaimer */}
        <div className="mt-12 pt-8 border-t border-border">
          <p className="text-[11px] text-muted-foreground leading-relaxed">
            <strong>DISCLAIMER:</strong> This site is an independent resource and is NOT affiliated, associated, authorized, endorsed by, or in any way officially connected with TikTok, ByteDance, Amazon.com, or any of their subsidiaries or affiliates. "TikTok," "BookTok," "KDP," "Amazon," and all related names, logos, and trademarks are the property of their respective owners. This website is for educational and informational purposes only. We do not claim ownership of any trademarks or intellectual property mentioned herein. All product names, logos, and brands are the property of their respective owners.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
