import { motion } from "framer-motion";
import { Boxes, ArrowUpRight } from "lucide-react";

const resources = [
  {
    name: "BookBolt",
    desc: "The #1 research tool for KDP authors. Find profitable niches, analyze competition, and validate book ideas before publishing.",
    category: "Research",
  },
  {
    name: "Canva",
    desc: "Create stunning TikTok videos, book covers, and marketing assets with drag-and-drop templates.",
    category: "Design",
  },
  {
    name: "Creative Fabrica",
    desc: "Premium fonts, graphics, and design assets for low-content and medium-content book creation.",
    category: "Assets",
  },
  {
    name: "ShipStation",
    desc: "Automate your TikTok Shop fulfillment. Connect orders, print labels, and scale shipping operations.",
    category: "Fulfillment",
  },
  {
    name: "Printful",
    desc: "Print-on-demand service for authors who want to test TikTok Shop without holding inventory.",
    category: "Fulfillment",
  },
  {
    name: "VidIQ",
    desc: "Optimize your TikTok and YouTube content strategy with AI-powered analytics and keyword tools.",
    category: "Analytics",
  },
];

const Resources = () => {
  return (
    <section id="resources" className="py-24 md:py-32 bg-grid">
      <div className="container max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: [0.2, 0, 0, 1] }}
        >
          <div className="flex items-center gap-3 mb-2">
            <Boxes className="w-5 h-5 text-primary" strokeWidth={1.5} />
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-widest">Resources</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tighter text-foreground mb-2">
            Recommended Tools
          </h2>
          <p className="text-sm text-muted-foreground mb-10">Everything you need to publish, market, and fulfill.</p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {resources.map((r, i) => (
              <a
                key={i}
                href="#"
                className="card-surface card-surface-hover p-6 group block"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] px-2 py-1 rounded bg-primary/10 text-primary font-medium uppercase tracking-widest">{r.category}</span>
                  <ArrowUpRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-all duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" strokeWidth={1.5} />
                </div>
                <h3 className="font-display font-semibold text-foreground mb-2">{r.name}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{r.desc}</p>
              </a>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Resources;
