import { motion } from "framer-motion";
import { BarChart3, Zap, Shield } from "lucide-react";

const features = [
  {
    icon: BarChart3,
    title: "Trend Identification",
    description: "Discover emerging market trends and high-demand niches before your competitors. Our AI-powered analytics identify profitable book categories and trending topics in real-time.",
  },
  {
    icon: Zap,
    title: "Content Automation",
    description: "Generate compelling book titles, descriptions, and marketing copy automatically. Save hours on content creation while maintaining professional quality and SEO optimization.",
  },
  {
    icon: Shield,
    title: "Fulfillment Optimization",
    description: "Streamline your entire publishing workflow from manuscript to market. Manage inventory, pricing strategies, and distribution channels all from one unified dashboard.",
  },
];

const Blueprint = () => {
  return (
    <section id="testimonials" className="py-24 md:py-32">
      <div className="container max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: [0.2, 0, 0, 1] }}
        >
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tighter text-foreground mb-4">
              Powerful Features Built for Your Success
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to dominate Amazon KDP and grow your author business exponentially.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.1, ease: [0.2, 0, 0, 1] }}
                  className="card-surface p-8 group hover:border-primary/50 transition-all duration-200"
                >
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                    <Icon className="w-6 h-6 text-primary" strokeWidth={1.5} />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Testimonials Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: [0.2, 0, 0, 1] }}
          className="mt-24 pt-24 border-t border-border"
        >
          <h2 className="text-3xl md:text-4xl font-bold tracking-tighter text-foreground mb-12 text-center">
            Success Stories from Real Authors
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                quote: "This platform transformed my KDP business. I went from 2 books to 15 in just 6 months using their trend identification and automation tools. My monthly revenue tripled!",
                author: "Sarah Mitchell",
                role: "Independent Author & Entrepreneur",
              },
              {
                quote: "The content automation feature alone saved me 20 hours per week. Combined with data-driven insights, I'm now making more money with less effort. Highly recommend!",
                author: "James Rodriguez",
                role: "Full-Time KDP Publisher",
              },
            ].map((testimonial, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1, ease: [0.2, 0, 0, 1] }}
                className="card-surface p-8"
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className="text-accent">★</span>
                  ))}
                </div>
                <p className="text-foreground mb-6 leading-relaxed italic">"{testimonial.quote}"</p>
                <div>
                  <p className="font-semibold text-foreground">{testimonial.author}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Blueprint;
