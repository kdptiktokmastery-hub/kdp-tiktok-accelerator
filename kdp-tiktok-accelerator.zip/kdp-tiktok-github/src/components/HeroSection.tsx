import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="pt-32 pb-24 md:pt-40 md:pb-32 relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10 pointer-events-none" />

      <div className="container max-w-5xl relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.2, 0, 0, 1] }}
          >
            <div className="mb-6">
              <span className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium uppercase tracking-widest">
                Resource Hub for Authors
              </span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tighter text-foreground mb-6 leading-tight">
              KDP TikTok Profit
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
                Accelerator
              </span>
            </h1>

            <p className="text-lg text-muted-foreground mb-8 leading-relaxed max-w-lg">
              A specialized resource hub designed for Amazon KDP authors to amplify their reach, automate content creation, and scale their publishing business with data-driven strategies.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="px-8 py-3 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 transition-all duration-200 flex items-center justify-center gap-2 group">
                Explore Now
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="px-8 py-3 border border-primary text-primary font-semibold rounded-lg hover:bg-primary/10 transition-all duration-200">
                Learn More
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mt-16 pt-8 border-t border-border">
              <div>
                <div className="text-2xl md:text-3xl font-bold text-primary mb-1">500+</div>
                <p className="text-xs text-muted-foreground uppercase tracking-widest">Active Authors</p>
              </div>
              <div>
                <div className="text-2xl md:text-3xl font-bold text-accent mb-1">2.5M+</div>
                <p className="text-xs text-muted-foreground uppercase tracking-widest">Book Sales</p>
              </div>
              <div>
                <div className="text-2xl md:text-3xl font-bold text-secondary mb-1">87%</div>
                <p className="text-xs text-muted-foreground uppercase tracking-widest">Success Rate</p>
              </div>
            </div>
          </motion.div>

          {/* Right side - Feature showcase */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2, ease: [0.2, 0, 0, 1] }}
            className="hidden md:block"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl blur-3xl" />
              <div className="relative bg-card rounded-2xl border border-border p-8 space-y-6">
                <div className="space-y-3">
                  <div className="h-3 bg-primary/20 rounded w-3/4" />
                  <div className="h-3 bg-primary/10 rounded w-full" />
                  <div className="h-3 bg-primary/10 rounded w-5/6" />
                </div>
                <div className="space-y-3">
                  <div className="h-3 bg-accent/20 rounded w-4/5" />
                  <div className="h-3 bg-accent/10 rounded w-full" />
                  <div className="h-3 bg-accent/10 rounded w-3/4" />
                </div>
                <div className="space-y-3">
                  <div className="h-3 bg-secondary/20 rounded w-full" />
                  <div className="h-3 bg-secondary/10 rounded w-5/6" />
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
