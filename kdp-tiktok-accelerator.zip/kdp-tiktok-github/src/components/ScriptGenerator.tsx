import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Copy, Check } from "lucide-react";

const hookTemplates = [
  "POV: You found the {genre} book that actually {emotion}... and it only costs $4.99 on Amazon. 📖✨ #{genre}Tok #BookTok #KDP",
  "This {genre} book is going VIRAL for a reason. '{title}' hits different when you're {emotion}. Link in bio. 🔥 #BookTok #{genre}",
  "I asked AI to write a {genre} book for {audience}... then I published it on KDP. Here's what happened. 📈 #KDPAuthor #BookTok",
  "Stop scrolling. If you're into {genre}, '{title}' was literally written for {audience}. Trust me. 💀 #BookRec #BookTok",
  "The book that {audience} didn't know they needed. '{title}' — a {genre} experience that will {emotion}. #BookTok #MustRead",
];

const emotions: Record<string, string> = {
  Romance: "makes you feel butterflies at 2AM",
  Fantasy: "transports you to another world",
  "Self-Help": "rewires your mindset overnight",
  Horror: "keeps you up all night",
  "Children's": "sparks pure joy",
  Journal: "heals your inner child",
  default: "changes your perspective completely",
};

const ScriptGenerator = () => {
  const [title, setTitle] = useState("");
  const [genre, setGenre] = useState("");
  const [audience, setAudience] = useState("");
  const [script, setScript] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  const generate = () => {
    if (!title.trim() || !genre.trim() || !audience.trim()) return;
    setIsGenerating(true);
    setTimeout(() => {
      const template = hookTemplates[Math.floor(Math.random() * hookTemplates.length)];
      const emotion = emotions[genre] || emotions.default;
      const result = template
        .replace(/{title}/g, title.trim())
        .replace(/{genre}/g, genre.trim())
        .replace(/{audience}/g, audience.trim())
        .replace(/{emotion}/g, emotion);
      setScript(result);
      setIsGenerating(false);
    }, 1200);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(script);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const inputClass = "w-full bg-muted/50 border-0 ring-1 ring-border rounded-lg px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:ring-2 focus:ring-primary outline-none transition-all duration-200";

  return (
    <section id="generator" className="py-24 md:py-32 bg-grid">
      <div className="container max-w-3xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: [0.2, 0, 0, 1] }}
        >
          <div className="flex items-center gap-3 mb-2">
            <Sparkles className="w-5 h-5 text-primary" strokeWidth={1.5} />
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-widest">AI Script Generator</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tighter text-foreground mb-2">
            Generate Your Viral Hook
          </h2>
          <p className="text-sm text-muted-foreground mb-10">Enter your book details and get a TikTok-ready script in seconds.</p>

          <div className="card-surface p-6 md:p-8 space-y-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground uppercase tracking-widest mb-2">Book Title</label>
              <input
                type="text"
                className={inputClass}
                placeholder="e.g. The Shadow Within"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                maxLength={100}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground uppercase tracking-widest mb-2">Genre</label>
              <input
                type="text"
                className={inputClass}
                placeholder="e.g. Dark Romance, Self-Help, Journal"
                value={genre}
                onChange={(e) => setGenre(e.target.value)}
                maxLength={50}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground uppercase tracking-widest mb-2">Target Audience</label>
              <input
                type="text"
                className={inputClass}
                placeholder="e.g. women 18-35 interested in healing"
                value={audience}
                onChange={(e) => setAudience(e.target.value)}
                maxLength={100}
              />
            </div>

            <button
              onClick={generate}
              disabled={isGenerating || !title.trim() || !genre.trim() || !audience.trim()}
              className="w-full relative bg-primary text-primary-foreground font-semibold py-3.5 rounded-lg transition-all duration-200 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden"
              style={{ transitionTimingFunction: "var(--easing)" }}
            >
              {isGenerating && <div className="absolute inset-0 shimmer" />}
              <span className="relative z-10">{isGenerating ? "Generating..." : "Generate Hook"}</span>
            </button>
          </div>

          <AnimatePresence>
            {script && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.4, ease: [0.2, 0, 0, 1] }}
                className="mt-6 relative"
              >
                <div className="bg-background p-6 rounded-lg font-mono text-sm leading-relaxed text-foreground"
                  style={{ boxShadow: "var(--shadow-card)" }}>
                  {script}
                </div>
                <button
                  onClick={copyToClipboard}
                  className="absolute top-3 right-3 p-2 rounded-md bg-muted/50 hover:bg-muted text-muted-foreground hover:text-foreground transition-colors duration-200"
                >
                  {copied ? <Check className="w-4 h-4 text-primary" strokeWidth={1.5} /> : <Copy className="w-4 h-4" strokeWidth={1.5} />}
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
};

export default ScriptGenerator;
