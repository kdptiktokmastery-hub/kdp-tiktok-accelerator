import Navbar from "../components/Navbar";
import HeroSection from "../components/HeroSection";
import TrendDashboard from "../components/TrendDashboard";
import ScriptGenerator from "../components/ScriptGenerator";
import Blueprint from "../components/Blueprint";
import Resources from "../components/Resources";
import Footer from "../components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <TrendDashboard />
      <ScriptGenerator />
      <Blueprint />
      <Resources />
      <Footer />
    </div>
  );
};

export default Index;
